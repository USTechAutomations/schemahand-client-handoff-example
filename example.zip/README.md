# SchemaHand client-handoff example (synthetic)

Every file in this zip is made up. No customer, client, or production database appears here.
No customer data.

This zip is a fixed worked example. It is not a general SQL parser and cannot process a buyer schema.

## Files

- source.sql — synthetic PostgreSQL CREATE TABLE script used as input
- handoff.html — SchemaHand HTML export with editable notes. Save edited copy writes a new HTML file. It does not update dictionary.csv.
- dictionary.csv — table and column dictionary from the same parse, including foreign keys
- README.md — this file
- MANIFEST.sha256 — SHA-256 of source.sql, handoff.html, dictionary.csv, and README.md

## Counts from the accepted engine on this input

- tables: 12
- columns: 54
- relationships: 15
- SQL statements not used as tables or relationships: 3 (CREATE SCHEMA app; CREATE SCHEMA audit; CREATE INDEX idx_orders_customer ON app.orders (customer_id))

## Limits

No database connection. No data migration. No query execution. Not universal SQL. No GDPR or compliance promise.
Notes typed in the saved HTML stay in that HTML copy. Changing that HTML does not update the separate CSV.

## Paid product this example leads to

SchemaHand offline edition, one-time $199:
https://ustechautomations.gumroad.com/l/schemahand-offline

This is not the Stripe 12-month browser-key offer.
